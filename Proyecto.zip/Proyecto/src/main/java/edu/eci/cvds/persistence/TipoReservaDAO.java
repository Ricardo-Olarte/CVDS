package edu.eci.cvds.persistence;

import edu.eci.cvds.entities.TipoReserva;

import java.util.List;

public interface TipoReservaDAO {
    public List<TipoReserva> consultarTipores();

}
