package edu.eci.cvds.persistence.mappers;

import edu.eci.cvds.entities.User;

import java.util.List;

public interface TipoUserMapper {
}
