package edu.eci.cvds.persistence.mappers;

import edu.eci.cvds.entities.Ubicacion;

import java.util.List;

public interface UbicacionMapper {
    public List<Ubicacion> consultarUbicacion();
}
