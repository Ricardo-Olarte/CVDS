package edu.eci.cvds.persistence.mappers;

import edu.eci.cvds.entities.TipoReserva;

import java.util.List;

public interface TipoReservaMapper {
    public List<TipoReserva> consultarTipores();

}
