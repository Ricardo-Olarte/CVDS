package edu.eci.cvds.persistence.mappers;

import edu.eci.cvds.entities.Recurso;

import java.util.List;

public interface HorarioMapper {
}
