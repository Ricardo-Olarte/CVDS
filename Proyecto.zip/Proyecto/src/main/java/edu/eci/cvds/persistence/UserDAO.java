package edu.eci.cvds.persistence;

import edu.eci.cvds.entities.User;
import org.apache.ibatis.exceptions.PersistenceException;

import java.util.List;

public interface UserDAO {
    public List<User> consultarUsuarios() throws PersistenceException;
}
