package edu.eci.cvds.persistence;

public interface HorarioDAO{
}
