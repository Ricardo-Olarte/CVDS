package edu.eci.cvds.entities;

public class TipoUser {
}
